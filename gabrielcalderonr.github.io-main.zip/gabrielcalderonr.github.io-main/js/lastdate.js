var string = document.lastModified;
document.getElementById("time").textContent = string;